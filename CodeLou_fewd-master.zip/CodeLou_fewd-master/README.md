# CodeLou_FrontEnd

## Description
```
My project is an expression of my favorite hobby...painting furniture and making it feel NEW.  This project is a personal website displaying furniture I have painted as well as furniture still on my 'to-do' list.  To view, open the index.html file.  
- Home Page:  (index.html) includes About, Images, and Contact sections.

Objectives: 
 - responsive
 - 3 custom CSS class or ID selectors (see ## Customer CSS Classes below)
 - Commenting Sections
 - Uploaded project to GitHub repository
 - README file (you're reading it!!)

```


## Custom CSS Classes
```
The class(es) I created are:

1. class name ex( .main-info-section )
.. what class does, ex( adds padding & changes background color of .main-info-section )

2. class name ex( .main-info-section )
.. what class does, ex( adds padding & changes background color of .main-info-section )

3. class name ex( .main-info-section )
.. what class does, ex( adds padding & changes background color of .main-info-section )

```



## Custom JavaScript Functions
```
The javascript functions I created are:

1. function name ex( animate() )
.. what function does ex( animate() is used to move the elements in the info div across the screen)

```
